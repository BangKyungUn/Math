
#include "stdafx.h"
#include "Triangle.h"

